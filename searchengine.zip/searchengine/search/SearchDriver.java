/**  
 * 
 * Copyright: Copyright (c) 2004 Carnegie Mellon University
 * 
 * This program is part of an implementation for the PARKR project which is 
 * about developing a search engine using efficient Datastructures.
 * 
 * Modified by Mahender K on 12-10-2009
 */ 


package searchengine.search;


import java.util.*;
import java.io.*;

import searchengine.dictionary.ObjectIterator;
import searchengine.indexer.Indexer;


/**
 * The user interface for the index structure.
 *
 * This class provides a main program that allows users to search a web
 * site for keywords.  It essentially uses the index structure generated
 * by WebIndex or ListWebIndex, depending on parameters, to do this.
 *
 * To run this, type the following:
 *
 *    % java SearchDriver indexfile list|custom keyword1 [keyword2] [keyword3] ...
 *
 * where indexfile is a file containing a saved index and list or custom indicates index structure.
 *
 */
public class SearchDriver
{
    public static void main(String [] args)
    {
        Vector<String> v=new Vector<String>();
	
	if(args.length<3)
	    System.out.println("Usage: java SearchDriver indexfile list|hash keyword1 [keyword2] [keyword3] [...]");
	else
	    {
		Indexer w = null;
		
		// Take care to use the right usage of the Index structure
		// hash - Dictionary Structure based on a Hashtable or HashMap from the Java collections 
		// list - Dictionary Structure based on Linked List 
		// myhash - Dictionary Structure based on a Hashtable implemented by the students
		// bst - Dictionary Structure based on a Binary Search Tree implemented by the students
		// avl - Dictionary Structure based on AVL Tree implemented by the students
		if(args[1].equalsIgnoreCase("list") || args[1].equals("hash") || args[1].equals("myhash") || args[1].equals("bst") 
				|| args[1].equals("avl")){
		    w = new Indexer(args[1]);
		}
		else
		{
			System.out.println("Invalid Indexer mode \n");
		}
		
		try{
		    FileInputStream indexSource=new FileInputStream(args[0]);
		    w.restore(indexSource);
		}
		catch(IOException e){
		    System.out.println(e.toString());
		}
		
		for(int i=2;i<args.length;i++)
		    v.addElement(args[i]);
		
		ObjectIterator<?> i= w.retrievePages(new ObjectIterator<String>(v));
		Hashtable<String,Integer> hm=new Hashtable<String,Integer>();
		
		
		if(i!=null)
		{	
			
			while(i.hasNext())
						{
							String s=(String) i.next();
							String[]b=s.split("####-->");
							
						System.out.println(b[0]);
							//System.out.println(b[1]);
							String h=b[1];
							
							String[] c=h.split("]");
							
							//System.out.println(c[0]);
						//	System.out.println(c[1]);
							
						   hm.put(b[0], Integer.parseInt(c[0]));
							int a=0;			
						//a=(Integer.parseInt(c[1])*(1/Integer.parseInt(c[0])))*100;
						//System.out.println(a);
						
						
						}int i1=0;
					int a=hm.size();
					String st[]=new String[a];
						Enumeration<String	> en=hm.keys();
						while(en.hasMoreElements())
						{
							st[i1]=(String) en.nextElement();
							System.out.println((String) en.nextElement());
							i1++;
						}
						
				

					 System.out.println("Search complete.");
						System.out.println("---------------\n");
					}
		else
		{
			System.out.println("Search complete.  0  hits found.");
		}
	    }
    }
};


