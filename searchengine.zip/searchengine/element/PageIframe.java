
package searchengine.element;

public class PageIframe implements PageElementInterface {

	public PageIframe (String h) /* perhaps throw an invalid filename error? */{
		iframe = h;
	}

	public String toString () {
		return iframe;
	}

	private String iframe;
}
