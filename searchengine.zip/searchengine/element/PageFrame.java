package searchengine.element;

public class PageFrame implements PageElementInterface {

	public PageFrame (String h) /* perhaps throw an invalid filename error? */{
		frame = h;
	}

	public String toString () {
		return frame;
	}

	private String frame;
}
