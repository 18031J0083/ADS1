package searchengine.dictionary;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
class ValCount
{
	Object value;
	int count;
}
public class HashDictionary implements DictionaryInterface {

		Hashtable<Object, Integer> h=new Hashtable<Object,Integer>();
		@SuppressWarnings("rawtypes")
		Hashtable<String,Hashtable> hm=new Hashtable<String,Hashtable>();
		@Override
		public String[] getKeys() {
			// TODO Auto-generated method stub
			int a=hm.size();
			int i=0;
			String st[]=new String[a];
			Enumeration<String	> en=hm.keys();
			while(en.hasMoreElements())
			{
				st[i]=(String) en.nextElement();
				i++;
			}
			return (String[]) st;
		}

		@Override
		public String getValue(String str) {
				// TODO Auto-generated method stub

				Hashtable s=hm.get(str);

				h=hm.get(str);

				Enumeration en=s.keys();

				String st="";

				while(en.hasMoreElements())

				{

					

					Object v=en.nextElement();

					//System.out.println(v);

					st=v+""

							+ "]"+h.get(v)+"\t"+st;
				}

				return st;
		}

		@SuppressWarnings("unchecked")
 		public void insert(String key, Object value) {
			// TODO Auto-generated method stub
		if (hm.containsKey(key)) {
			h = hm.get(key);
			if (h.containsKey(value)) {
				int a = h.get(value);
				a++;
				h.put((Object) value, a);
			} else {
				h.put((Object) value, 1);
				hm.put(key, h);
			}
		} else {
			h = new Hashtable<Object, Integer>();
			h.put((Object) value, 1);
			hm.put(key, h);
		}

	}

		@Override
		public void remove(String key) {
			// TODO Auto-generated method stub
			hm.remove(key);
		}

	}
