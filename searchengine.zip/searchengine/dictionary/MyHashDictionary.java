package searchengine.dictionary;
import java.util.ArrayList;
import java.util.Vector;
class ValueHash
{
	String  v;
	ArrayList<String> ar;
	ValueHash()
	{
     ar=new ArrayList<String>();
	}
}
class Hash
{
	String key;
	ValueHash value;
	Hash(String key,ValueHash value )
	{
		this.key=key;
		this.value=value;
	}
}
	
public class MyHashDictionary implements DictionaryInterface {
	Hash[] a=new Hash[400];
	int size=0;
	public int hashfunc(String s)
	{
		
		int sum=0;
		for(int i = 0;i<s.length();i++)
		{
			sum=sum+s.charAt(i)*(i+1);
		}
		sum=sum%400;
		
		return sum;
	}
	public String[] getKeys() {
		// TODO Auto-generated method stub
		String[] st=new String[size];
		int j=0,i=0;
		for(j=0;j<a.length;j++)
		{
			if(a[j]!=null )
			{
				st[i]=(String) a[j].key;
				i++;
			}
			
		}
		

		return st;
	}

	@Override
	public Object getValue(String key) {
		// TODO Auto-generated method stub
		int no=hashfunc(key);
		return a[no].value.ar;
	}

	@Override
	public void insert(String key, Object value) {
		// TODO Auto-generated method stub
		size++;
		
		if(a[hashfunc(key)]!=null)
		{
			a[hashfunc(key)].value.ar.add((String) value);
			
			size--;
		}
		else
		{
			
			String str=(String) value;
			ValueHash v1=new ValueHash();
			v1.v=str;
			Hash h=new Hash(key, v1);
			a[hashfunc(key)]= h;
			a[hashfunc(key)].value.ar.add((String) value);
		}
		
		
		
	}

	@Override
	public void remove(String key) {
		// TODO Auto-generated method stub

		size--;
		a[hashfunc(key)]=null;

}
}
