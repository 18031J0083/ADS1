package searchengine.dictionary;

import java.util.ArrayList;
class BstValue
{
	public String toString() {
		return  val + "-->" + count ;
	}

	String val;
	int count=0;

	public BstValue(String value,int count)
	{
		this.val=value;
		this.count=count;
	}
	
}


class Treenode
{
	String key;
	ArrayList<BstValue> va=new ArrayList<BstValue>();
	Treenode left,right;

	Treenode(String key, String value)
	{
		this.key=key;
		BstValue v=new BstValue(value,1);	
		va.add(v);
		
		left=right=null;	}
	
}
 class BST
{
	 int count;
	 String st[]=new String[count];
	Treenode root;
	BST()
	{
		root=null;
		count=0;
	}
	
	int n=0;
	public void put(String Key,String value)
	{
		count++;
		root=put(root,Key,value);
	}
	private Treenode put (Treenode x, String key, String value)
	{
		
		if(x==null)
		{
			
			return new Treenode(key,value);
		}
		if(key.compareTo((String) x.key)<0)
		{
			//count++;
			x.left=put(x.left,key,value);
		}
		else if(key.compareTo((String) x.key)>0)
		{
			//count++;
			x.right=put(x.right,key,value);
		}
		else
		{
			if(x.va.contains(value))
			{int c1=0;
				for(int i = 0;i<x.va.size();i++)
				{
					 String svale=x.va.get(i).val;
		    		 if( value.equals(svale))
		   					{
		   							c1=1;
		   							x.va.get(i).count++;
		   							break;
		   					}
		    	 }
		    	 if(c1==0)
		    	 {
		    		 x.va.add(new BstValue(value,1));
		    	 }
				}
			else
			{
				 x.va.add(new BstValue(value,1));
			}
			}
		
		return x;
	}
	
	public ArrayList<BstValue> get( String key) {
		return get(root,key);
	}
	
	public ArrayList<BstValue> get(Treenode x, String key) { 
	if (x == null) {
		
		return null;}
	else
	{
	int cmp =key.compareTo((String) x.key) ;  
	if (cmp < 0) 
	return get(x.left, key);     
	else if (cmp > 0) 
	return get(x.right, key);   
	else return x.va; 
	}
	}

	void deleteKey(String key) 
    { count--;
        root = deleteRec(root, key); 
    } 
  
   
    Treenode deleteRec(Treenode root,  String key) 
    { 
        
        if (root == null)  return root; 
  
      
        if (key.compareTo((String) root.key)<0) 
            root.left = deleteRec(root.left, key); 
        else if (key.compareTo((String) root.key) >0) 
            root.right = deleteRec(root.right, key); 
  
      
        else
        { 
            
            if (root.left == null) 
                return root.right; 
            else if (root.right == null) 
                return root.left; 
  
            
            root.key = (String) minValue(root.right); 
  
            root.right = deleteRec(root.right, (String) root.key); 
        } 
  
        return root; 
    } 
  
    String minValue(Treenode root) 
    { 
    	String minv=root.key;
        while (root.left != null) 
        { 
            minv = root.left.key; 
            root = root.left; 
        } 
        return minv; 
    } 
    public String[] inorderbe()
	{
	ArrayList<String> al=new ArrayList<String>();
	inorderbe(root,al);
	int size=al.size();
	String [] s=new String[size];
	for(int i=0;i<size;i++)
	{
		s[i]=(String)al.get(i);
	}
	
	return s;
		
	}
	public void inorderbe(Treenode n,ArrayList al)
	{
		
		if(n!=null) {
		inorderbe(n.left,al);
		
		al.add(n.key);
			
		
		inorderbe(n.right,al);
	
		}
	
	
}
}
public class BSTDictionary implements DictionaryInterface {
	BST b=new BST();
	@Override
	public String[] getKeys() {
		// TODO Auto-generated method stub
		return b.inorderbe();
	}

	@Override
	public Object getValue(String key) {
		// TODO Auto-generated method stub
		return b.get(key);
	}

	@Override
	public void insert(String key, Object value) {
		// TODO Auto-generated method stub

		b.put(key, (String) value);
	}

	@Override
	public void remove(String key) {
		// TODO Auto-generated method stub
		b.deleteKey(key) ;
	}

}
